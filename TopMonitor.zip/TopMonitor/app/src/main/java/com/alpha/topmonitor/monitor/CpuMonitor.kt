package com.alpha.topmonitor.monitor

import android.os.Process
import android.os.SystemClock
import com.alpha.topmonitor.core.CpuMath
import com.alpha.topmonitor.core.CpuTimes
import java.io.File

/**
 * Reads CPU figures that an ordinary app is allowed to see.
 *
 * System-wide usage comes from /proc/stat. Since Android 8 most devices block that file for
 * normal apps, so after three failed reads we stop trying and report null (shown as "N/A").
 * Nothing here ever estimates or invents a value.
 */
class CpuMonitor {
    private val cores = Runtime.getRuntime().availableProcessors().coerceAtLeast(1)

    private var prevStat: CpuTimes? = null
    private var statFailures = 0
    private var statBroken = false

    private var prevAppCpuMs = -1L
    private var prevWallMs = -1L

    fun sample(): CpuSample {
        val system = readSystem()
        val app = readApp()
        var sum = 0L
        var count = 0
        var max = 0L
        for (i in 0 until cores) {
            val base = "/sys/devices/system/cpu/cpu$i/cpufreq/"
            readLong(base + "scaling_cur_freq")?.let { sum += it; count++ }
            readLong(base + "cpuinfo_max_freq")?.let { if (it > max) max = it }
        }
        return CpuSample(
            systemPercent = system,
            appPercent = app,
            cores = cores,
            avgFreqKhz = if (count > 0) sum / count else null,
            maxFreqKhz = if (max > 0L) max else null,
            systemStatAvailable = !statBroken
        )
    }

    private fun readSystem(): Float? {
        if (statBroken) return null
        val times = try {
            CpuMath.parseProcStat(File("/proc/stat").readText())
        } catch (e: Exception) {
            null
        }
        if (times == null) {
            statFailures++
            if (statFailures >= 3) statBroken = true
            return null
        }
        statFailures = 0
        val prev = prevStat
        prevStat = times
        return if (prev == null) null else CpuMath.usagePercent(prev, times)
    }

    private fun readApp(): Float? {
        val cpuMs = Process.getElapsedCpuTime()
        val wallMs = SystemClock.elapsedRealtime()
        val result = if (prevAppCpuMs >= 0L) {
            CpuMath.appPercent(cpuMs - prevAppCpuMs, wallMs - prevWallMs, cores)
        } else null
        prevAppCpuMs = cpuMs
        prevWallMs = wallMs
        return result
    }

    private fun readLong(path: String): Long? = try {
        File(path).readText().trim().toLongOrNull()
    } catch (e: Exception) {
        null
    }
}
