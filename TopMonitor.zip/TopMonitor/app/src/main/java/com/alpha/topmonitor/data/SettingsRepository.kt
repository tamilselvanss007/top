package com.alpha.topmonitor.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.MutablePreferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

private val Context.settingsStore: DataStore<Preferences> by preferencesDataStore(name = "topmonitor_settings")

class SettingsRepository(context: Context) {
    private val store = context.applicationContext.settingsStore

    val settings: Flow<OverlaySettings> = store.data
        .catch { e -> if (e is IOException) emit(emptyPreferences()) else throw e }
        .map { read(it) }

    suspend fun update(transform: (OverlaySettings) -> OverlaySettings) {
        store.edit { prefs -> write(prefs, transform(read(prefs))) }
    }

    private object K {
        val ENABLED = booleanPreferencesKey("overlay_enabled")
        val SHOW_CPU = booleanPreferencesKey("show_cpu")
        val SHOW_RAM = booleanPreferencesKey("show_ram")
        val SHOW_DETAIL = booleanPreferencesKey("show_ram_detail")
        val EXPANDED = booleanPreferencesKey("expanded")
        val CLICK_THROUGH = booleanPreferencesKey("click_through")
        val INTERVAL = longPreferencesKey("interval_ms")
        val ANCHOR = stringPreferencesKey("anchor")
        val POS_X = intPreferencesKey("pos_x")
        val POS_Y = intPreferencesKey("pos_y")
        val OPACITY = intPreferencesKey("bg_opacity")
        val TEXT_SIZE = intPreferencesKey("text_size")
        val TEXT_COLOR = intPreferencesKey("text_color")
        val BG_COLOR = intPreferencesKey("bg_color")
    }

    private fun read(p: Preferences): OverlaySettings {
        val d = OverlaySettings()
        return OverlaySettings(
            overlayEnabled = p[K.ENABLED] ?: d.overlayEnabled,
            showCpu = p[K.SHOW_CPU] ?: d.showCpu,
            showRam = p[K.SHOW_RAM] ?: d.showRam,
            showRamDetail = p[K.SHOW_DETAIL] ?: d.showRamDetail,
            expanded = p[K.EXPANDED] ?: d.expanded,
            clickThrough = p[K.CLICK_THROUGH] ?: d.clickThrough,
            intervalMs = p[K.INTERVAL] ?: d.intervalMs,
            anchor = p[K.ANCHOR]?.let { runCatching { AnchorPosition.valueOf(it) }.getOrNull() } ?: d.anchor,
            posX = p[K.POS_X] ?: d.posX,
            posY = p[K.POS_Y] ?: d.posY,
            bgOpacityPercent = p[K.OPACITY] ?: d.bgOpacityPercent,
            textSizeSp = p[K.TEXT_SIZE] ?: d.textSizeSp,
            textColor = p[K.TEXT_COLOR] ?: d.textColor,
            bgColor = p[K.BG_COLOR] ?: d.bgColor
        )
    }

    private fun write(p: MutablePreferences, s: OverlaySettings) {
        p[K.ENABLED] = s.overlayEnabled
        p[K.SHOW_CPU] = s.showCpu
        p[K.SHOW_RAM] = s.showRam
        p[K.SHOW_DETAIL] = s.showRamDetail
        p[K.EXPANDED] = s.expanded
        p[K.CLICK_THROUGH] = s.clickThrough
        p[K.INTERVAL] = s.intervalMs
        p[K.ANCHOR] = s.anchor.name
        p[K.POS_X] = s.posX
        p[K.POS_Y] = s.posY
        p[K.OPACITY] = s.bgOpacityPercent
        p[K.TEXT_SIZE] = s.textSizeSp
        p[K.TEXT_COLOR] = s.textColor
        p[K.BG_COLOR] = s.bgColor
    }
}
