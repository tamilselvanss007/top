package com.alpha.topmonitor.data

enum class AnchorPosition { LEFT, CENTER, RIGHT }

data class OverlaySettings(
    val overlayEnabled: Boolean = false,
    val showCpu: Boolean = true,
    val showRam: Boolean = true,
    val showRamDetail: Boolean = true,
    val expanded: Boolean = false,
    val clickThrough: Boolean = false,
    val intervalMs: Long = 1000L,
    val anchor: AnchorPosition = AnchorPosition.CENTER,
    /** Offset in pixels from the anchor edge (from the centre line for CENTER). */
    val posX: Int = 0,
    val posY: Int = 0,
    val bgOpacityPercent: Int = 70,
    val textSizeSp: Int = 12,
    val textColor: Int = 0xFFFFFFFF.toInt(),
    val bgColor: Int = 0xFF000000.toInt()
)
