package com.alpha.topmonitor.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.alpha.topmonitor.R
import com.alpha.topmonitor.data.OverlaySettings
import com.alpha.topmonitor.data.PerformanceRepository
import com.alpha.topmonitor.data.SettingsRepository
import com.alpha.topmonitor.monitor.CpuMonitor
import com.alpha.topmonitor.monitor.RamMonitor
import com.alpha.topmonitor.monitor.Snapshot
import com.alpha.topmonitor.overlay.OverlayController
import com.alpha.topmonitor.ui.MainActivity
import com.alpha.topmonitor.util.Permissions
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * The single service in the app: it samples CPU/RAM and draws the overlay.
 * Running as a foreground service keeps it alive on Android 8+ and shows the required notification.
 */
class FloatingOverlayService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val writeScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private lateinit var settingsRepo: SettingsRepository
    private lateinit var cpu: CpuMonitor
    private lateinit var ram: RamMonitor
    private lateinit var overlay: OverlayController

    private var current = OverlaySettings()
    private var started = false
    private var hidden = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        settingsRepo = SettingsRepository(applicationContext)
        cpu = CpuMonitor()
        ram = RamMonitor(applicationContext)
        overlay = OverlayController(
            context = this,
            onPositionChanged = { x, y ->
                writeScope.launch { settingsRepo.update { it.copy(posX = x, posY = y) } }
            },
            onTap = {
                writeScope.launch { settingsRepo.update { it.copy(expanded = !it.expanded) } }
            }
        )
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                disableAndStop()
                return START_NOT_STICKY
            }
            ACTION_TOGGLE_HIDE -> {
                if (!started) {
                    stopSelf()
                    return START_NOT_STICKY
                }
                hidden = !hidden
                overlay.setVisible(!hidden)
                notifyUpdate()
                return START_STICKY
            }
        }

        if (!Permissions.canDrawOverlays(this)) {
            disableAndStop()
            return START_NOT_STICKY
        }
        if (!started) {
            if (!enterForeground()) {
                stopSelf()
                return START_NOT_STICKY
            }
            started = true
            PerformanceRepository.setServiceRunning(true)
            begin()
        }
        return START_STICKY
    }

    private fun begin() {
        scope.launch {
            current = settingsRepo.settings.first()
            if (!overlay.show(current)) {
                disableAndStop()
                return@launch
            }
            overlay.setVisible(!hidden)

            // Keep the overlay in step with settings changed on the dashboard.
            launch {
                settingsRepo.settings.collect { s ->
                    current = s
                    overlay.apply(s)
                }
            }

            // The first CPU reading only primes the counters, so wait a moment before the loop.
            withContext(Dispatchers.Default) { cpu.sample() }
            delay(400)
            while (isActive) {
                val snap = withContext(Dispatchers.Default) {
                    Snapshot(System.currentTimeMillis(), cpu.sample(), ram.sample())
                }
                PerformanceRepository.publish(snap)
                overlay.update(snap)
                delay(current.intervalMs.coerceAtLeast(500L))
            }
        }
    }

    private fun enterForeground(): Boolean = try {
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
        true
    } catch (e: Exception) {
        false
    }

    private fun disableAndStop() {
        writeScope.launch { settingsRepo.update { it.copy(overlayEnabled = false) } }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (started) overlay.onConfigurationChanged()
    }

    override fun onDestroy() {
        scope.cancel()
        overlay.remove()
        PerformanceRepository.setServiceRunning(false)
        super.onDestroy()
    }

    private fun createChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            getString(R.string.channel_name),
            NotificationManager.IMPORTANCE_LOW
        ).apply { description = getString(R.string.channel_desc) }
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
            .createNotificationChannel(channel)
    }

    private fun notifyUpdate() {
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
            .notify(NOTIF_ID, buildNotification())
    }

    private fun buildNotification(): Notification {
        val immutable = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), immutable)
        val stop = PendingIntent.getService(
            this, 1, Intent(this, FloatingOverlayService::class.java).setAction(ACTION_STOP), immutable
        )
        val hide = PendingIntent.getService(
            this, 2, Intent(this, FloatingOverlayService::class.java).setAction(ACTION_TOGGLE_HIDE), immutable
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_monitor)
            .setContentTitle(getString(R.string.notif_title))
            .setContentText(getString(if (hidden) R.string.notif_text_hidden else R.string.notif_text_active))
            .setContentIntent(open)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .addAction(0, getString(R.string.action_stop), stop)
            .addAction(0, getString(if (hidden) R.string.action_show else R.string.action_hide), hide)
            .build()
    }

    companion object {
        const val ACTION_STOP = "com.alpha.topmonitor.action.STOP"
        const val ACTION_TOGGLE_HIDE = "com.alpha.topmonitor.action.TOGGLE_HIDE"
        private const val CHANNEL_ID = "monitoring"
        private const val NOTIF_ID = 1001

        fun start(context: Context) {
            ContextCompat.startForegroundService(
                context, Intent(context, FloatingOverlayService::class.java)
            )
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, FloatingOverlayService::class.java))
        }
    }
}
