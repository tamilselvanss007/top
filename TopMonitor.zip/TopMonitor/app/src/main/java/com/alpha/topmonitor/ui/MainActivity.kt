package com.alpha.topmonitor.ui

import android.Manifest
import android.content.ActivityNotFoundException
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.updatePadding
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.alpha.topmonitor.R
import com.alpha.topmonitor.core.Format
import com.alpha.topmonitor.data.AnchorPosition
import com.alpha.topmonitor.data.OverlaySettings
import com.alpha.topmonitor.data.PerformanceRepository
import com.alpha.topmonitor.data.SettingsRepository
import com.alpha.topmonitor.monitor.CpuMonitor
import com.alpha.topmonitor.monitor.HistoryPoint
import com.alpha.topmonitor.monitor.RamMonitor
import com.alpha.topmonitor.monitor.Snapshot
import com.alpha.topmonitor.service.FloatingOverlayService
import com.alpha.topmonitor.util.Permissions
import com.google.android.material.button.MaterialButton
import com.google.android.material.button.MaterialButtonToggleGroup
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.slider.Slider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private lateinit var repo: SettingsRepository
    private lateinit var ramMonitor: RamMonitor
    private val cpuMonitor = CpuMonitor()

    private var settings = OverlaySettings()
    private var suppress = false
    private var pendingEnable = false
    private var sliderJob: Job? = null

    private val notifLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (!granted) Toast.makeText(this, R.string.toast_notif_denied, Toast.LENGTH_LONG).show()
            startOverlay()
        }

    private fun <T : View> v(id: Int): T = findViewById(id)

    private val swOverlay by lazy { v<MaterialSwitch>(R.id.swOverlay) }
    private val swShowCpu by lazy { v<MaterialSwitch>(R.id.swShowCpu) }
    private val swShowRam by lazy { v<MaterialSwitch>(R.id.swShowRam) }
    private val swShowDetail by lazy { v<MaterialSwitch>(R.id.swShowDetail) }
    private val swExpanded by lazy { v<MaterialSwitch>(R.id.swExpanded) }
    private val swClickThrough by lazy { v<MaterialSwitch>(R.id.swClickThrough) }
    private val tgPosition by lazy { v<MaterialButtonToggleGroup>(R.id.tgPosition) }
    private val tgInterval by lazy { v<MaterialButtonToggleGroup>(R.id.tgInterval) }
    private val sliderOpacity by lazy { v<Slider>(R.id.sliderOpacity) }
    private val sliderSize by lazy { v<Slider>(R.id.sliderSize) }
    private val tvOpacity by lazy { v<TextView>(R.id.tvOpacity) }
    private val tvSize by lazy { v<TextView>(R.id.tvSize) }
    private val rowTextColors by lazy { v<LinearLayout>(R.id.rowTextColors) }
    private val rowBgColors by lazy { v<LinearLayout>(R.id.rowBgColors) }
    private val tvPerm by lazy { v<TextView>(R.id.tvPerm) }
    private val tvNotif by lazy { v<TextView>(R.id.tvNotif) }
    private val btnGrant by lazy { v<MaterialButton>(R.id.btnGrant) }
    private val tvBattery by lazy { v<TextView>(R.id.tvBattery) }
    private val chartCpu by lazy { v<SparklineView>(R.id.chartCpu) }
    private val chartRam by lazy { v<SparklineView>(R.id.chartRam) }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        repo = SettingsRepository(applicationContext)
        ramMonitor = RamMonitor(applicationContext)

        ViewCompat.setOnApplyWindowInsetsListener(v<View>(R.id.scroll)) { view, insets ->
            val bars = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
            )
            view.updatePadding(left = bars.left, top = bars.top, right = bars.right, bottom = bars.bottom)
            insets
        }

        chartCpu.lineColor = ContextCompat.getColor(this, R.color.cpu_line)
        chartRam.lineColor = ContextCompat.getColor(this, R.color.ram_line)

        wireListeners()

        lifecycleScope.launch {
            // Recreated process: bring the overlay back if the user left it switched on.
            val saved = repo.settings.first()
            if (saved.overlayEnabled && Permissions.canDrawOverlays(this@MainActivity) &&
                !PerformanceRepository.serviceRunning.value
            ) {
                FloatingOverlayService.start(this@MainActivity)
            }
        }

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch { repo.settings.collect { render(it) } }
                launch { PerformanceRepository.latest.filterNotNull().collect { renderSnapshot(it) } }
                launch { PerformanceRepository.history.collect { renderHistory(it) } }
                launch { localSampleLoop() }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        renderStatus()
        if (pendingEnable) {
            pendingEnable = false
            if (Permissions.canDrawOverlays(this)) proceedAfterOverlayPermission()
            else Toast.makeText(this, R.string.toast_overlay_denied, Toast.LENGTH_LONG).show()
        }
    }

    // ---- Sampling while the overlay service is not running -------------------------------

    private suspend fun localSampleLoop() {
        PerformanceRepository.serviceRunning.collectLatest { running ->
            if (running) return@collectLatest
            withContext(Dispatchers.Default) { cpuMonitor.sample() }
            delay(400)
            while (true) {
                val snap = withContext(Dispatchers.Default) {
                    Snapshot(System.currentTimeMillis(), cpuMonitor.sample(), ramMonitor.sample())
                }
                PerformanceRepository.publish(snap)
                delay(settings.intervalMs.coerceAtLeast(500L))
            }
        }
    }

    // ---- Listeners -----------------------------------------------------------------------

    private fun wireListeners() {
        swOverlay.setOnCheckedChangeListener { _, checked ->
            if (suppress) return@setOnCheckedChangeListener
            if (checked) requestEnable() else stopOverlay()
        }
        btnGrant.setOnClickListener { openOverlayPermission() }

        swShowCpu.setOnCheckedChangeListener { _, checked ->
            if (suppress) return@setOnCheckedChangeListener
            if (!checked && !settings.showRam) keepOneMetric() else update { it.copy(showCpu = checked) }
        }
        swShowRam.setOnCheckedChangeListener { _, checked ->
            if (suppress) return@setOnCheckedChangeListener
            if (!checked && !settings.showCpu) keepOneMetric() else update { it.copy(showRam = checked) }
        }
        bindSwitch(swShowDetail) { s, on -> s.copy(showRamDetail = on) }
        bindSwitch(swExpanded) { s, on -> s.copy(expanded = on) }
        bindSwitch(swClickThrough) { s, on -> s.copy(clickThrough = on) }

        tgPosition.addOnButtonCheckedListener { _, id, isChecked ->
            if (!isChecked || suppress) return@addOnButtonCheckedListener
            val anchor = when (id) {
                R.id.btnPosLeft -> AnchorPosition.LEFT
                R.id.btnPosRight -> AnchorPosition.RIGHT
                else -> AnchorPosition.CENTER
            }
            update { it.copy(anchor = anchor, posX = 0) }
        }
        tgInterval.addOnButtonCheckedListener { _, id, isChecked ->
            if (!isChecked || suppress) return@addOnButtonCheckedListener
            val ms = when (id) {
                R.id.btnInt2 -> 2000L
                R.id.btnInt3 -> 3000L
                else -> 1000L
            }
            update { it.copy(intervalMs = ms) }
        }

        sliderOpacity.addOnChangeListener { _, value, fromUser ->
            if (!fromUser) return@addOnChangeListener
            tvOpacity.text = getString(R.string.opacity_fmt, value.toInt())
            debounced { it.copy(bgOpacityPercent = value.toInt()) }
        }
        sliderSize.addOnChangeListener { _, value, fromUser ->
            if (!fromUser) return@addOnChangeListener
            tvSize.text = getString(R.string.size_fmt, value.toInt())
            debounced { it.copy(textSizeSp = value.toInt()) }
        }

        findViewById<View>(R.id.btnResetPos).setOnClickListener {
            update { it.copy(anchor = AnchorPosition.CENTER, posX = 0, posY = 0) }
        }
        findViewById<View>(R.id.btnBattery).setOnClickListener {
            try {
                startActivity(Permissions.batteryOptimizationSettingsIntent())
            } catch (e: ActivityNotFoundException) {
                Toast.makeText(this, R.string.battery_limited, Toast.LENGTH_LONG).show()
            }
        }
        findViewById<View>(R.id.btnStopAll).setOnClickListener {
            stopOverlay()
            Toast.makeText(this, R.string.toast_stopped, Toast.LENGTH_SHORT).show()
        }
    }

    private fun bindSwitch(sw: MaterialSwitch, change: (OverlaySettings, Boolean) -> OverlaySettings) {
        sw.setOnCheckedChangeListener { _, checked ->
            if (!suppress) update { change(it, checked) }
        }
    }

    private fun keepOneMetric() {
        Toast.makeText(this, R.string.toast_one_metric, Toast.LENGTH_SHORT).show()
        render(settings) // put the switch back
    }

    private fun update(transform: (OverlaySettings) -> OverlaySettings) {
        lifecycleScope.launch { repo.update(transform) }
    }

    private fun debounced(transform: (OverlaySettings) -> OverlaySettings) {
        sliderJob?.cancel()
        sliderJob = lifecycleScope.launch {
            delay(120)
            repo.update(transform)
        }
    }

    // ---- Enable / disable flow -----------------------------------------------------------

    private fun requestEnable() {
        if (!Permissions.canDrawOverlays(this)) {
            suppress = true
            swOverlay.isChecked = false
            suppress = false
            MaterialAlertDialogBuilder(this)
                .setTitle(R.string.dlg_overlay_title)
                .setMessage(R.string.dlg_overlay_msg)
                .setPositiveButton(R.string.dlg_continue) { _, _ ->
                    pendingEnable = true
                    openOverlayPermission()
                }
                .setNegativeButton(android.R.string.cancel, null)
                .show()
            return
        }
        proceedAfterOverlayPermission()
    }

    private fun proceedAfterOverlayPermission() {
        if (Permissions.needsNotificationPermission() && !Permissions.hasNotificationPermission(this)) {
            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            startOverlay()
        }
    }

    private fun openOverlayPermission() {
        try {
            startActivity(Permissions.overlaySettingsIntent(this))
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, R.string.toast_overlay_denied, Toast.LENGTH_LONG).show()
        }
    }

    private fun startOverlay() {
        lifecycleScope.launch {
            repo.update { it.copy(overlayEnabled = true) }
            FloatingOverlayService.start(this@MainActivity)
        }
    }

    private fun stopOverlay() {
        lifecycleScope.launch { repo.update { it.copy(overlayEnabled = false) } }
        FloatingOverlayService.stop(this)
    }

    // ---- Rendering -----------------------------------------------------------------------

    private fun render(s: OverlaySettings) {
        settings = s
        suppress = true
        try {
            swOverlay.isChecked = s.overlayEnabled
            swShowCpu.isChecked = s.showCpu
            swShowRam.isChecked = s.showRam
            swShowDetail.isChecked = s.showRamDetail
            swExpanded.isChecked = s.expanded
            swClickThrough.isChecked = s.clickThrough

            tgPosition.check(
                when (s.anchor) {
                    AnchorPosition.LEFT -> R.id.btnPosLeft
                    AnchorPosition.CENTER -> R.id.btnPosCenter
                    AnchorPosition.RIGHT -> R.id.btnPosRight
                }
            )
            tgInterval.check(
                when (s.intervalMs) {
                    2000L -> R.id.btnInt2
                    3000L -> R.id.btnInt3
                    else -> R.id.btnInt1
                }
            )

            val opacity = (s.bgOpacityPercent.coerceIn(20, 100) / 5) * 5
            val size = s.textSizeSp.coerceIn(10, 20)
            tvOpacity.text = getString(R.string.opacity_fmt, opacity)
            tvSize.text = getString(R.string.size_fmt, size)
            if (!sliderOpacity.isPressed) sliderOpacity.value = opacity.toFloat()
            if (!sliderSize.isPressed) sliderSize.value = size.toFloat()

            fillSwatches(rowTextColors, TEXT_COLORS, s.textColor) { c -> update { it.copy(textColor = c) } }
            fillSwatches(rowBgColors, BG_COLORS, s.bgColor) { c -> update { it.copy(bgColor = c) } }
        } finally {
            suppress = false
        }
    }

    private fun fillSwatches(row: LinearLayout, colors: IntArray, selected: Int, onPick: (Int) -> Unit) {
        row.removeAllViews()
        val d = resources.displayMetrics.density
        val sizePx = (34 * d).toInt()
        val gap = (10 * d).toInt()
        for (c in colors) {
            val swatch = View(this)
            val circle = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(c)
                if (c == selected) setStroke((3 * d).toInt(), ContextCompat.getColor(this@MainActivity, R.color.accent))
                else setStroke((1 * d).toInt(), 0x55FFFFFF)
            }
            swatch.background = circle
            swatch.layoutParams = LinearLayout.LayoutParams(sizePx, sizePx).apply { marginEnd = gap }
            swatch.setOnClickListener { onPick(c) }
            row.addView(swatch)
        }
    }

    private fun renderStatus() {
        val granted = Permissions.canDrawOverlays(this)
        tvPerm.setText(if (granted) R.string.perm_overlay_granted else R.string.perm_overlay_missing)
        tvPerm.setTextColor(ContextCompat.getColor(this, if (granted) R.color.ok else R.color.warn))
        btnGrant.visibility = if (granted) View.GONE else View.VISIBLE

        tvNotif.setText(
            when {
                !Permissions.needsNotificationPermission() -> R.string.notif_not_required
                Permissions.hasNotificationPermission(this) -> R.string.notif_granted
                else -> R.string.notif_missing
            }
        )
        val unrestricted = Permissions.isIgnoringBatteryOptimizations(this)
        tvBattery.setText(if (unrestricted) R.string.battery_ok else R.string.battery_limited)
    }

    private fun renderSnapshot(s: Snapshot) {
        val cpu = s.cpu
        val ram = s.ram

        v<TextView>(R.id.tvCpuBig).text = Format.percent(cpu.systemPercent)
        v<TextView>(R.id.tvCpuSub).setText(
            if (cpu.systemStatAvailable) R.string.cpu_sub_system else R.string.cpu_sub_unavailable
        )
        v<TextView>(R.id.tvCpuApp).text = getString(R.string.cpu_app_fmt, Format.percent(cpu.appPercent))

        val avg = Format.freq(cpu.avgFreqKhz)
        val max = Format.freq(cpu.maxFreqKhz)
        v<TextView>(R.id.tvCpuDetail).text =
            if (avg != null) {
                getString(R.string.cpu_detail_fmt, cpu.cores, avg, max ?: "n/a") + "\n" +
                    getString(R.string.cpu_freq_note)
            } else {
                getString(R.string.cpu_detail_cores_only_fmt, cpu.cores)
            }
        val note = v<TextView>(R.id.tvCpuNote)
        note.setText(R.string.cpu_restricted_note)
        note.visibility = if (cpu.systemStatAvailable) View.GONE else View.VISIBLE

        v<TextView>(R.id.tvRamBig).text = Format.percent(ram.percent)
        v<TextView>(R.id.tvRamDetail).text = getString(
            R.string.ram_detail_fmt,
            Format.gb(ram.usedBytes), Format.gb(ram.availBytes), Format.gb(ram.totalBytes)
        )
        val appRam = v<TextView>(R.id.tvRamApp)
        val pss = ram.appPssBytes
        appRam.visibility = if (pss == null) View.GONE else View.VISIBLE
        if (pss != null) appRam.text = getString(R.string.ram_app_fmt, Format.mb(pss))
        v<TextView>(R.id.tvRamLow).visibility = if (ram.lowMemory) View.VISIBLE else View.GONE
    }

    private fun renderHistory(points: List<HistoryPoint>) {
        chartCpu.setData(
            points.map { it.cpu },
            getString(if (points.isEmpty()) R.string.chart_waiting else R.string.chart_na)
        )
        chartRam.setData(points.map { it.ram }, getString(R.string.chart_waiting))
    }

    companion object {
        private val TEXT_COLORS = intArrayOf(
            0xFFFFFFFF.toInt(), 0xFF4DD0E1.toInt(), 0xFF69F0AE.toInt(),
            0xFFFFEB3B.toInt(), 0xFFFF9800.toInt(), 0xFFFF80AB.toInt()
        )
        private val BG_COLORS = intArrayOf(
            0xFF000000.toInt(), 0xFF1E232B.toInt(), 0xFF0D1B3E.toInt(),
            0xFF0B2B1E.toInt(), 0xFF3B0F14.toInt(), 0xFFFFFFFF.toInt()
        )
    }
}
