package com.alpha.topmonitor.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class FormatTest {
    private val gib = 1024L * 1024L * 1024L

    @Test
    fun gigabytesUseBinaryUnitsWithOneDecimal() {
        assertEquals("8.0", Format.gb(8 * gib))
        assertEquals("3.5", Format.gb(gib * 7 / 2))
    }

    @Test
    fun megabytesAreWholeNumbers() {
        assertEquals("512", Format.mb(512L * 1024L * 1024L))
    }

    @Test
    fun percentRoundsAndShowsNotAvailableForNull() {
        assertEquals("N/A", Format.percent(null))
        assertEquals("32%", Format.percent(32.4f))
        assertEquals("68%", Format.percent(67.5f))
    }

    @Test
    fun frequencyPicksUnit() {
        assertEquals("1.80 GHz", Format.freq(1_800_000L))
        assertEquals("850 MHz", Format.freq(850_000L))
        assertNull(Format.freq(null))
        assertNull(Format.freq(0L))
    }
}
